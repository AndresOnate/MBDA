insert into regiones (nombre) values ('Europa');
insert into regiones (nombre) values ('Norte America');
insert into regiones (nombre) values ('Africa');
insert into regiones (nombre) values ('Sur America');
insert into regiones (nombre) values ('Asia');
insert into regiones (nombre) values ('Oceania');